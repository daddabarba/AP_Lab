function [ name ] = studentname
%function [ name ] = studentname  
%edit this file and define the string variable 'weare' to hold your name
%weare = 'studentname'

wearelist={'Waldorf & Statler','Kruder und Dorfmeister', ...
           'Beavis & Butthead', 'Pat & Mat', 'Thelma and Louise', ...
           'Oates and Garfunkel', 'Beyonce and Jay Z'};

if ~exist('weare','var')
  weare = wearelist{ceil(rand*length(wearelist))};

itis=clock;
name=sprintf('%s %02d.%02d.%4d %02d:%02d',weare,itis([3,2,1,4,5]));

end