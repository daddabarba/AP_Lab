function wait()
    waitforbuttonpress;
    close all;
end